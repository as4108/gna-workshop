import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from features import explain, extract  # noqa: E402


class FeatureTests(unittest.TestCase):
    def test_ip_host_is_detected(self):
        self.assertEqual(extract("http://192.168.1.5/login")["has_ip"], 1)

    def test_at_symbol_is_detected(self):
        self.assertEqual(extract("http://paypal.com@10.0.0.9/verify")["has_at_symbol"], 1)

    def test_missing_scheme_is_handled(self):
        features = extract("github.com/about")
        self.assertEqual(features["uses_https"], 0)
        self.assertEqual(features["has_ip"], 0)

    def test_https_is_detected(self):
        self.assertEqual(extract("https://www.python.org")["uses_https"], 1)

    def test_url_without_host_raises(self):
        with self.assertRaises(ValueError):
            extract("http://")

    def test_explain_mentions_ip(self):
        reasons = explain(extract("http://192.168.1.5/login"))
        self.assertTrue(any("IP address" in r for r in reasons))


if __name__ == "__main__":
    unittest.main()
