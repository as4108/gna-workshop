import json
import os
import sys
import unittest

ROOT = os.path.join(os.path.dirname(__file__), "..")
sys.path.insert(0, os.path.join(ROOT, "src"))

import lambda_handler  # noqa: E402

MODEL_EXISTS = os.path.exists(lambda_handler.MODEL_PATH)


def call(payload):
    body = payload if isinstance(payload, str) else json.dumps(payload)
    result = lambda_handler.handler({"body": body}, None)
    return result["statusCode"], json.loads(result["body"])


class HandlerValidationTests(unittest.TestCase):
    def test_invalid_json(self):
        self.assertEqual(call("not json")[0], 400)

    def test_missing_url(self):
        self.assertEqual(call({})[0], 400)

    def test_url_too_long(self):
        self.assertEqual(call({"url": "http://a.com/" + "x" * 3000})[0], 400)

    def test_unreadable_url(self):
        self.assertEqual(call({"url": "http://"})[0], 400)


@unittest.skipUnless(MODEL_EXISTS, "Run `python src/train.py` first")
class HandlerPredictionTests(unittest.TestCase):
    def test_obvious_phishing_url_is_flagged(self):
        status, body = call({"url": "http://192.168.4.7:8080/login/paypal/index.php"})
        self.assertEqual(status, 200)
        self.assertNotEqual(body["verdict"], "likely safe")
        self.assertTrue(body["reasons"])

    def test_normal_site_is_likely_safe(self):
        status, body = call({"url": "https://www.python.org/about"})
        self.assertEqual(status, 200)
        self.assertEqual(body["verdict"], "likely safe")


if __name__ == "__main__":
    unittest.main()
