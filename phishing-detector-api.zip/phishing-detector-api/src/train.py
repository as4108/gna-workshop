"""Train the phishing URL classifier and save it with joblib.

Usage: python src/train.py --data data/sample_urls.csv --out model/model.joblib
"""
import argparse
import csv
import os

import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split

from features import extract, vectorize


def load(path):
    X, y = [], []
    with open(path, newline="") as f:
        for row in csv.DictReader(f):
            try:
                X.append(vectorize(extract(row["url"])))
                y.append(int(row["label"]))
            except ValueError:
                continue  # skip malformed URLs
    return X, y


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/sample_urls.csv")
    ap.add_argument("--out", default="model/model.joblib")
    args = ap.parse_args()

    X, y = load(args.data)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    model = RandomForestClassifier(n_estimators=150, max_depth=12, random_state=42, n_jobs=-1)
    model.fit(X_train, y_train)
    print(classification_report(y_test, model.predict(X_test), target_names=["legitimate", "phishing"]))

    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
    joblib.dump(model, args.out)
    print(f"Saved model to {args.out}")


if __name__ == "__main__":
    main()
