"""Generate a SYNTHETIC labelled URL dataset (label 1 = phishing, 0 = legitimate).

This is only for demos and tests. Replace data/sample_urls.csv with a real
dataset (PhishTank, OpenPhish, Kaggle phishing URL sets) for meaningful results.
"""
import csv
import random

random.seed(42)

LEGIT_HOSTS = ["github.com", "wikipedia.org", "python.org", "stackoverflow.com", "mozilla.org",
               "apache.org", "khanacademy.org", "coursera.org", "nasa.gov", "who.int", "kernel.org"]
LEGIT_SUBS = ["", "www.", "docs.", "en.", "blog.", "learn."]
LEGIT_PATHS = ["", "/about", "/docs/getting-started", "/wiki/Cloud_computing", "/blog/2025/release-notes",
               "/courses/intro-to-security", "/downloads", "/search?q=network+security&page=2", "/users/profile"]
BRANDS = ["paypal", "amazon", "sbi", "hdfc", "netflix", "microsoft", "google", "apple", "instagram"]
WORDS = ["login", "verify", "secure", "account", "update", "confirm", "signin", "billing", "wallet"]
BAD_TLDS = ["xyz", "top", "tk", "ml", "click", "work", "info", "cf", "gq", "com", "net"]


def rand_str(n):
    return "".join(random.choice("abcdefghijklmnopqrstuvwxyz0123456789") for _ in range(n))


def rand_ip():
    return ".".join(str(random.randint(1, 254)) for _ in range(4))


def legit():
    scheme = "https" if random.random() < 0.9 else "http"
    return f"{scheme}://{random.choice(LEGIT_SUBS)}{random.choice(LEGIT_HOSTS)}{random.choice(LEGIT_PATHS)}"


def phish():
    scheme = "https" if random.random() < 0.4 else "http"
    b, w, t = random.choice(BRANDS), random.choice(WORDS), random.choice(BAD_TLDS)
    kind = random.randint(0, 4)
    if kind == 0:
        return f"http://{rand_ip()}/{w}/{b}/index.php"
    if kind == 1:
        return f"{scheme}://{b}-{w}-{rand_str(4)}.{t}/{w}.html"
    if kind == 2:
        return f"{scheme}://{w}.{b}.{rand_str(5)}.{rand_str(3)}.{t}/signin?session={rand_str(16)}&id={random.randint(1000, 99999)}"
    if kind == 3:
        return f"http://{b}.com@{rand_ip()}:{random.choice([8080, 8443, 2087])}/{w}"
    return f"{scheme}://secure-{b}-{w}.{t}//{w}/{rand_str(8)}/verify-account"


if __name__ == "__main__":
    rows = [(legit(), 0) for _ in range(1000)] + [(phish(), 1) for _ in range(1000)]
    random.shuffle(rows)
    with open("data/sample_urls.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["url", "label"])
        w.writerows(rows)
    print(f"Wrote {len(rows)} rows to data/sample_urls.csv")
