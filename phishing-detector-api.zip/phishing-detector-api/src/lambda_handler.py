"""AWS Lambda entry point for POST /check with body {"url": "..."}."""
import json
import os

import joblib

from features import extract, explain, vectorize

MODEL_PATH = os.environ.get(
    "MODEL_PATH",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "model", "model.joblib"),
)
MAX_URL_LENGTH = 2048
_model = None  # loaded once per container, reused across invocations


def get_model():
    global _model
    if _model is None:
        _model = joblib.load(MODEL_PATH)
    return _model


def respond(status, body):
    return {"statusCode": status, "headers": {"Content-Type": "application/json"}, "body": json.dumps(body)}


def verdict_for(score):
    if score >= 0.7:
        return "phishing"
    if score >= 0.4:
        return "suspicious"
    return "likely safe"


def handler(event, context):
    try:
        body = json.loads(event.get("body") or "{}")
    except json.JSONDecodeError:
        return respond(400, {"error": 'Send JSON like {"url": "https://example.com"}'})

    url = body.get("url") if isinstance(body, dict) else None
    if not isinstance(url, str) or not url.strip():
        return respond(400, {"error": "Missing 'url' field"})
    if len(url) > MAX_URL_LENGTH:
        return respond(400, {"error": f"URL is longer than {MAX_URL_LENGTH} characters"})

    try:
        features = extract(url)
    except ValueError:
        return respond(400, {"error": "Could not read a valid host from that URL"})

    score = float(get_model().predict_proba([vectorize(features)])[0][1])
    return respond(200, {
        "url": url.strip(),
        "verdict": verdict_for(score),
        "phishing_probability": round(score, 3),
        "reasons": explain(features),
    })
