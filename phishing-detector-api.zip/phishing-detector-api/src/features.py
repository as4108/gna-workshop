"""URL feature extraction and plain-language explanations."""
import math
import re
from urllib.parse import urlparse

SUSPICIOUS_WORDS = (
    "login", "signin", "verify", "secure", "account", "update", "bank",
    "confirm", "password", "wallet", "bonus", "free", "billing", "support",
)
SUSPICIOUS_TLDS = {"xyz", "top", "tk", "ml", "ga", "cf", "gq", "click", "work", "zip", "country"}
IP_RE = re.compile(r"^\d{1,3}(\.\d{1,3}){3}$")
SCHEME_RE = re.compile(r"^[a-zA-Z][a-zA-Z0-9+.-]*://")

FEATURE_NAMES = [
    "url_length", "host_length", "num_dots", "num_subdomains", "has_ip",
    "has_at_symbol", "num_hyphens_host", "num_digits_host", "digit_ratio_url",
    "uses_https", "num_suspicious_words", "suspicious_tld", "path_length",
    "num_query_params", "host_entropy", "double_slash_in_path", "custom_port",
]


def normalize(url: str) -> str:
    """Add a scheme if missing so urlparse reads the host correctly."""
    url = url.strip()
    return url if SCHEME_RE.match(url) else "http://" + url


def _entropy(text: str) -> float:
    if not text:
        return 0.0
    counts = {c: text.count(c) for c in set(text)}
    return -sum((n / len(text)) * math.log2(n / len(text)) for n in counts.values())


def extract(url: str) -> dict:
    """Return a dict of numeric features. Raises ValueError for unparseable URLs."""
    full = normalize(url)
    parsed = urlparse(full)  # may raise ValueError
    host = (parsed.hostname or "").lower()
    if not host:
        raise ValueError("No host found in URL")
    lowered = full.lower()
    tld = host.rsplit(".", 1)[-1]
    return {
        "url_length": len(full),
        "host_length": len(host),
        "num_dots": host.count("."),
        "num_subdomains": max(host.count(".") - 1, 0),
        "has_ip": int(bool(IP_RE.match(host))),
        "has_at_symbol": int("@" in full),
        "num_hyphens_host": host.count("-"),
        "num_digits_host": sum(c.isdigit() for c in host),
        "digit_ratio_url": sum(c.isdigit() for c in full) / len(full),
        "uses_https": int(parsed.scheme == "https"),
        "num_suspicious_words": sum(w in lowered for w in SUSPICIOUS_WORDS),
        "suspicious_tld": int(tld in SUSPICIOUS_TLDS),
        "path_length": len(parsed.path),
        "num_query_params": len([p for p in parsed.query.split("&") if p]),
        "host_entropy": _entropy(host),
        "double_slash_in_path": int("//" in parsed.path),
        "custom_port": int(parsed.port not in (None, 80, 443)),
    }


def vectorize(features: dict) -> list:
    return [float(features[name]) for name in FEATURE_NAMES]


def explain(features: dict) -> list:
    """Human-readable reasons, based on simple rules (separate from the ML score)."""
    reasons = []
    if features["has_ip"]:
        reasons.append("Uses a raw IP address instead of a domain name")
    if features["has_at_symbol"]:
        reasons.append("Contains an @ symbol, which can hide the real destination")
    if features["num_suspicious_words"] >= 2:
        reasons.append("Contains several words common in phishing (login, verify, secure...)")
    if features["suspicious_tld"]:
        reasons.append("Ends in a domain extension often used for throwaway sites")
    if features["num_subdomains"] >= 3:
        reasons.append("Has an unusually long chain of subdomains")
    if features["num_hyphens_host"] >= 2:
        reasons.append("Domain name contains multiple hyphens")
    if features["url_length"] > 75:
        reasons.append("URL is unusually long")
    if features["custom_port"]:
        reasons.append("Uses a non-standard port")
    if not features["uses_https"]:
        reasons.append("Does not use HTTPS")
    return reasons
